import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart'; // Import Firebase Core
import 'package:Home/screens/notifications.dart';
import 'screens/home_screen.dart';
import 'screens/garden.dart';  // Import the garden screen
import 'screens/splash_screen.dart';
import 'package:Home/screens/sensor_readings_page.dart';
import 'package:Home/screens/crop_readings_page.dart'; // Import the CropReadingsPage
  // Import the NotificationService

void main() async {
  // Ensure that Firebase is initialized before running the app
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Initialize Firebase

  // Initialize notifications
  await NotificationService.initialize();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Home Automation',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: SplashScreen(), // Start with SplashScreen
      routes: {
        '/home': (context) => HomeScreen(),
        '/garden': (context) => SensorReadingsPage(), // Add route for GardenScreen
        '/crop': (context) => CropReadingsPage(), // Add route for CropReadingsPage
      },
    );
  }
}
