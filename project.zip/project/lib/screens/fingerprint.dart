import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: FingerprintScreen(),
    );
  }
}

class FingerprintScreen extends StatefulWidget {
  @override
  _FingerprintScreenState createState() => _FingerprintScreenState();
}

class _FingerprintScreenState extends State<FingerprintScreen> {
  final LocalAuthentication auth = LocalAuthentication();

  // Function to handle biometric authentication
  Future<void> _authenticate() async {
    bool isAuthenticated = false;

    try {
      // Check if biometrics are available and the device is supported
      bool canAuthenticateWithBiometrics = await auth.canCheckBiometrics;
      bool canAuthenticate = canAuthenticateWithBiometrics || await auth.isDeviceSupported();

      if (canAuthenticate) {
        // Trigger authentication using biometrics
        isAuthenticated = await auth.authenticate(
          localizedReason: 'Please authenticate to proceed',
          options: const AuthenticationOptions(
            biometricOnly: true, // Only biometric authentication
          ),
        );
      } else {
        // Handle case where biometrics are not available or device is not supported
        print('Biometrics not available or device not supported');
      }
    } on PlatformException catch (e) {
      // Handle any exceptions during authentication
      print('Error during authentication: ${e.message}');
    }

    if (isAuthenticated) {
      // Proceed after successful authentication
      print('Authentication successful!');
    } else {
      // Handle failed authentication
      print('Authentication failed');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fingerprint Authentication"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: _authenticate, // Trigger authentication when pressed
          child: Text('Authenticate with Fingerprint'),
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15), // Padding for button
            textStyle: TextStyle(fontSize: 16), // Button text style
          ),
        ),
      ),
    );
  }
}
