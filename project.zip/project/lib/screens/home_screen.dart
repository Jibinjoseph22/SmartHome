import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import '../services/api_service.dart';
import '../screens/splash_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final LocalAuthentication auth = LocalAuthentication();

  Map<String, bool> deviceStates = {
    "Light 1": false,
    "Light 2": false,
    "Light 3": false,
    "Light 4": false,
    "Fan 1": false,
    "Fan 2": false,
  };

  bool isFrontDoorLocked = true;
  bool isGateLocked = true;
  bool isNightModeOn = false;

  Future<void> _authenticateAndToggleDoor() async {
    bool isAuthenticated = false;

    try {
      bool canAuthenticateWithBiometrics = await auth.canCheckBiometrics;
      bool canAuthenticate = canAuthenticateWithBiometrics || await auth.isDeviceSupported();

      if (canAuthenticate) {
        isAuthenticated = await auth.authenticate(
          localizedReason: 'Please authenticate to proceed',
          options: const AuthenticationOptions(biometricOnly: true),
        );
      }
    } on PlatformException catch (e) {
      print('Error during authentication: ${e.message}');
    }

    if (isAuthenticated) {
      toggleFrontDoor();
    } else {
      print('Authentication failed');
    }
  }

  Future<void> toggleFrontDoor() async {
    bool success = isFrontDoorLocked ? await ApiService.unlockDoor() : await ApiService.lockDoor();

    if (success) {
      setState(() {
        isFrontDoorLocked = !isFrontDoorLocked;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(isFrontDoorLocked ? "Door Locked" : "Door Unlocked")),
      );
    }
  }

  Future<void> toggleGate() async {
    bool success = isGateLocked ? await ApiService.unlockGate() : await ApiService.lockGate();

    if (success) {
      setState(() {
        isGateLocked = !isGateLocked;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(isGateLocked ? "Gate Locked" : "Gate Unlocked")),
      );
    }
  }

  Future<void> toggleDevice(BuildContext context, String device) async {
    bool success = await ApiService.toggleDevice(device);
    if (success) {
      setState(() {
        deviceStates[device] = !deviceStates[device]!;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("$device toggled successfully!")),
      );
    }
  }

  Future<void> toggleNightMode() async {
    bool success = isNightModeOn
        ? await ApiService.nightModeOff()
        : await ApiService.nightModeOn();

    if (success) {
      setState(() {
        isNightModeOn = !isNightModeOn;
      });

      // Turn off all lights (SEND API REQUESTS)
      // Turn off all lights (SEND API REQUESTS) only if they are on
      for (String light in ["Light 1", "Light 2", "Light 3", "Light 4"]) {
        if (deviceStates[light]!) {  // Only toggle if the light is ON
          bool lightSuccess = await ApiService.toggleDevice(light);
          if (lightSuccess) {
            setState(() {
              deviceStates[light] = false;
            });
          }
        }
      }


      // Lock the front door (SEND API REQUEST)
      if (!isFrontDoorLocked) {
        bool doorSuccess = await ApiService.lockDoor();
        if (doorSuccess) {
          setState(() {
            isFrontDoorLocked = true;
          });
        }
      }

      // Lock the gate (SEND API REQUEST)
      if (!isGateLocked) {
        bool gateSuccess = await ApiService.lockGate();
        if (gateSuccess) {
          setState(() {
            isGateLocked = true;
          });
        }
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(isNightModeOn ? "Night Mode Activated" : "Night Mode Deactivated")),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("Home"),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => SplashScreen()),
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Welcome Back, Home",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              SizedBox(height: 20),

              _statusTile("Front Door", isFrontDoorLocked ? "Locked" : "Unlocked",
                  isFrontDoorLocked ? Icons.lock : Icons.lock_open, isFrontDoorLocked ? Colors.red : Colors.green,
                  _authenticateAndToggleDoor),

              _statusTile("Gate", isGateLocked ? "Locked" : "Unlocked",
                  isGateLocked ? Icons.door_sliding : Icons.door_back_door, isGateLocked ? Colors.red : Colors.green,
                  toggleGate),

              SizedBox(height: 10),

              _deviceControl("Light 1", "Room 1 Light", Icons.lightbulb),
              _deviceControl("Light 2", "Room 2 Light", Icons.lightbulb),
              _deviceControl("Light 3", "Room 3 Light", Icons.lightbulb),
              _deviceControl("Light 4", "Room 4 Light", Icons.lightbulb),
              _deviceControl("Fan 1", "Fan 1", Icons.ac_unit),
              _deviceControl("Fan 2", "Fan 2", Icons.ac_unit),

              SizedBox(height: 20),

              ElevatedButton(
                onPressed: toggleNightMode,
                style: ElevatedButton.styleFrom(
                  backgroundColor: isNightModeOn ? Colors.red : Colors.blue,
                  padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                ),
                child: Text(
                  isNightModeOn ? "Disable Night Mode" : "Enable Night Mode",
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),

              SizedBox(height: 20), // Add some spacing at the bottom
            ],
          ),
        ),
      ),

    );
  }

  Widget _statusTile(String title, String subtitle, IconData icon, Color iconColor, VoidCallback onTap) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: iconColor),
      title: Text(title, style: TextStyle(color: Colors.white, fontSize: 18)),
      subtitle: Text(subtitle, style: TextStyle(color: Colors.white54)),
    );
  }

  Widget _deviceControl(String device, String room, IconData icon) {
    return ListTile(
      leading: Icon(icon, color: deviceStates[device]! ? Colors.green : Colors.white54),
      title: Text(room, style: TextStyle(color: Colors.white)),
      subtitle: Text(deviceStates[device]! ? "On" : "Off", style: TextStyle(color: Colors.white54)),
      trailing: Switch(
        value: deviceStates[device]!,
        onChanged: (value) => toggleDevice(context, device),
        activeColor: Colors.green,
      ),
    );
  }
}
