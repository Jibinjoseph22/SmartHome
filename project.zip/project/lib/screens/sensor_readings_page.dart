import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart'; // For graph visualization
import 'package:Home/screens/splash_screen.dart';
import 'package:Home/services/api_service.dart'; // Import ApiService

class SensorReadingsPage extends StatefulWidget {
  @override
  _SensorReadingsPageState createState() => _SensorReadingsPageState();
}

class _SensorReadingsPageState extends State<SensorReadingsPage> {
  double soilMoisture = 0.0;
  double humidity = 0.0;
  double temperature = 0.0;
  double lightIntensity = 0.0;

  Timer? _timer;

  // Use ApiService to fetch sensor data
  Future<void> _fetchSensorData() async {
    try {
      final data = await ApiService.fetchSensorData();

      if (data != null) {
        setState(() {
          soilMoisture = data['Soil Moisture'] ?? 0.0;
          humidity = data['Humidity'] ?? 0.0;
          temperature = data['Temperature'] ?? 0.0;
          lightIntensity = data['Light Intensity'] ?? 0.0;
        });
      } else {
        print('Failed to load sensor data.');
      }
    } catch (e) {
      print('Error fetching sensor data: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchSensorData();

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      _fetchSensorData();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Crop Data", style: TextStyle(color: Colors.white)),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => SplashScreen()),
                  (route) => false,
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSensorCard("Soil Moisture", soilMoisture, Colors.green),
            _buildSensorCard("Temperature", temperature, Colors.red),
            _buildSensorCard("Humidity", humidity, Colors.blue),
            _buildSensorCard("Light Intensity", lightIntensity, Colors.yellow),
          ],
        ),
      ),
    );
  }

  Widget _buildSensorCard(String label, double value, Color graphColor) {
    return Card(
      color: Colors.grey[900],
      margin: EdgeInsets.symmetric(vertical: 12),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 18, color: Colors.white),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "${value.toStringAsFixed(2)}",
                  style: TextStyle(fontSize: 24, color: Colors.white),
                ),
                Text(
                  "Last 7 days",
                  style: TextStyle(fontSize: 12, color: Colors.white60),
                ),
              ],
            ),
            SizedBox(height: 16),
            SizedBox(
              height: 100,
              child: LineChart(
                LineChartData(
                  lineBarsData: [
                    LineChartBarData(
                      isCurved: true,
                      color: graphColor,
                      barWidth: 3,
                      isStrokeCapRound: true,
                      belowBarData: BarAreaData(
                        show: true,
                        gradient: LinearGradient(
                          colors: [
                            graphColor.withOpacity(0.4),
                            Colors.transparent,
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                      spots: List.generate(7, (index) {
                        double fluctuation = (index % 2 == 0 ? 1 : -1) * (index * 2.5);
                        return FlSpot(
                          index.toDouble(),
                          (value + fluctuation).clamp(0, 100),
                        );
                      }),
                    ),
                  ],
                  gridData: FlGridData(show: true, drawVerticalLine: true),
                  borderData: FlBorderData(
                    show: true,
                    border: Border.all(color: Colors.white24),
                  ),
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, _) => Text(
                          "Day ${(value + 1).toInt()}",
                          style: TextStyle(fontSize: 10, color: Colors.white70),
                        ),
                        reservedSize: 22,
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
