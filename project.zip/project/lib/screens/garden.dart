import 'package:flutter/material.dart';
import 'sensor_readings_page.dart'; // Import the SensorReadingsPage
import 'crop_readings_page.dart';  // Import the CropReadingsPage
import 'splash_screen.dart';      // Import the SplashScreen

class GardenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/garden_background.jpeg"), // Your image path
                fit: BoxFit.cover, // Ensures the image covers the entire screen
              ),
            ),
          ),
          // Page content
          Column(
            children: [
              // AppBar with back button
              AppBar(
                backgroundColor: Colors.black.withOpacity(0.7), // Semi-transparent AppBar
                title: Text(
                  "Garden Management",
                  style: TextStyle(color: Colors.white),
                ),
                centerTitle: true,
                leading: IconButton(
                  icon: Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () {
                    // Navigate back to SplashScreen
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => SplashScreen()),
                          (route) => false,
                    );
                  },
                ),
              ),
              // Decorative header
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 40.0),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.green, Colors.yellow], // A softer green-yellow gradient
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(50.0),
                    bottomRight: Radius.circular(50.0),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.eco, size: 64.0, color: Colors.white),
                    SizedBox(height: 10),
                    Text(
                      "Welcome to Garden Management",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "Manage your plants and crops efficiently.",
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 16.0,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 50), // Space between header and buttons
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildNavigationButton(
                        context,
                        "Go to Sensor Readings",
                        Icons.thermostat,
                        Colors.green,
                        Colors.lightGreenAccent,
                        SensorReadingsPage(),
                      ),
                      SizedBox(height: 30), // More space between buttons
                      _buildNavigationButton(
                        context,
                        "Go to Crop Readings",
                        Icons.agriculture,
                        Colors.orange,
                        Colors.deepOrangeAccent,
                        CropReadingsPage(),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationButton(
      BuildContext context,
      String text,
      IconData icon,
      Color startColor,
      Color endColor,
      Widget page) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      child: Container(
        height: 70, // Increased button height for better interactivity
        width: double.infinity, // Full width button
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [startColor, endColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20), // Larger rounded corners
          boxShadow: [
            BoxShadow(
              color: startColor.withOpacity(0.5),
              blurRadius: 10,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 32), // Larger icon
            SizedBox(width: 12),
            Text(
              text,
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
