import 'dart:ui';

import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';

class NotificationService {
  // Initialize the notification service
  static Future<void> initialize() async {
    await AwesomeNotifications().initialize(
      '',
      [
        NotificationChannel(
          channelKey: 'basic_channel',
          channelName: 'Basic notifications',
          channelDescription: 'Notification channel for basic notifications',
          defaultColor: Color(0xFF9D50DD),
          ledColor: Colors.white,
        ),
      ],
    );
    // Request notification permissions
    await _requestNotificationPermissions();
  }

  // Request notification permissions
  static Future<void> _requestNotificationPermissions() async {
    final isAllowed = await AwesomeNotifications().isNotificationAllowed();
    if (!isAllowed) {
      // Request permission
      await AwesomeNotifications().requestPermissionToSendNotifications();
    }
  }

  static void showNotification(String title, String message) {
    // Generate a 32-bit signed integer ID by using the modulo operation
    int notificationId = (DateTime
        .now()
        .millisecondsSinceEpoch % (1 << 31)); // Limit to 32-bit

    AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: notificationId, // Use the 32-bit ID
        channelKey: 'basic_channel',
        title: title,
        body: message,
      ),
    );
  }

}