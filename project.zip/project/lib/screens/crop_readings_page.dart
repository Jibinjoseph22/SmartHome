import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'sensor_readings_page.dart';

class CropReadingsPage extends StatefulWidget {
  @override
  _CropReadingsPageState createState() => _CropReadingsPageState();
}

class _CropReadingsPageState extends State<CropReadingsPage> {
  final TextEditingController cropNameController = TextEditingController();
  final TextEditingController fertilizerNameController = TextEditingController();
  final TextEditingController soilMoistureController = TextEditingController();
  final TextEditingController humidityController = TextEditingController();
  final TextEditingController temperatureController = TextEditingController();
  final TextEditingController lightIntensityController = TextEditingController();
  final TextEditingController cropSearchController = TextEditingController();

  Map<String, dynamic>? selectedCropData;

  // Save crop data to Firestore
  Future<void> _saveCropData() async {
    try {
      String cropName = cropNameController.text.trim();
      String fertilizerName = fertilizerNameController.text.trim();
      double soilMoisture = double.tryParse(soilMoistureController.text) ?? 0.0;
      double humidity = double.tryParse(humidityController.text) ?? 0.0;
      double temperature = double.tryParse(temperatureController.text) ?? 0.0;
      double lightIntensity = double.tryParse(lightIntensityController.text) ?? 0.0;

      if (cropName.isNotEmpty) {
        FirebaseFirestore.instance.collection('crops').doc(cropName).set({
          'soilMoisture': soilMoisture,
          'humidity': humidity,
          'temperature': temperature,
          'lightIntensity': lightIntensity,
          'fertilizerName': fertilizerName,
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Crop data saved successfully')),
        );

        cropNameController.clear();
        fertilizerNameController.clear();
        soilMoistureController.clear();
        humidityController.clear();
        temperatureController.clear();
        lightIntensityController.clear();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Crop name cannot be empty')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving crop data: $e')),
      );
    }
  }

  // Search crop data from Firestore
  Future<void> _searchCropData(String cropName) async {
    try {
      var cropData = await FirebaseFirestore.instance.collection('crops').doc(cropName).get();

      if (cropData.exists) {
        setState(() {
          selectedCropData = cropData.data()!;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Crop data not found')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error searching for crop data: $e')),
      );
    }
  }

  // Delete crop data from Firestore
  Future<void> _deleteCropData(String cropName) async {
    try {
      await FirebaseFirestore.instance.collection('crops').doc(cropName).delete();
      setState(() {
        selectedCropData = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Crop data deleted successfully')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting crop data: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Check Crop Readings", style: TextStyle(color: Colors.white)),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => SensorReadingsPage()),
                  (route) => false,
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: cropSearchController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Search Crop Name',
                labelStyle: TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.grey[800],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                _searchCropData(cropSearchController.text.trim());
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: Text('Search Crop'),
            ),
            if (selectedCropData != null) ...[
              _buildCropDataCard('Soil Moisture', selectedCropData!['soilMoisture'], Colors.green),
              _buildCropDataCard('Humidity', selectedCropData!['humidity'], Colors.blue),
              _buildCropDataCard('Temperature', selectedCropData!['temperature'], Colors.red),
              _buildCropDataCard('Light Intensity', selectedCropData!['lightIntensity'], Colors.yellow),
              _buildCropDataCard('Fertilizer Name', selectedCropData!['fertilizerName'] ?? 'N/A', Colors.orange),
              ElevatedButton(
                onPressed: () {
                  _deleteCropData(cropSearchController.text.trim());
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: Text('Delete Crop Data'),
              ),
            ],
            SizedBox(height: 20),
            _buildTextField(cropNameController, 'Enter Crop Name'),
            _buildTextField(fertilizerNameController, 'Enter Fertilizer Name'),
            _buildTextField(soilMoistureController, 'Enter Soil Moisture', isNumeric: true),
            _buildTextField(humidityController, 'Enter Humidity', isNumeric: true),
            _buildTextField(temperatureController, 'Enter Temperature', isNumeric: true),
            _buildTextField(lightIntensityController, 'Enter Light Intensity', isNumeric: true),
            ElevatedButton(
              onPressed: _saveCropData,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: Text('Save Crop Data'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCropDataCard(String label, dynamic value, Color color) {
    return Card(
      color: Colors.grey[900],
      margin: EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(
          label,
          style: TextStyle(color: Colors.white),
        ),
        subtitle: Text(
          value.toString(),
          style: TextStyle(color: color),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, {bool isNumeric = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        keyboardType: isNumeric ? TextInputType.number : TextInputType.text,
        style: TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.white70),
          filled: true,
          fillColor: Colors.grey[800],
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
    );
  }
}
