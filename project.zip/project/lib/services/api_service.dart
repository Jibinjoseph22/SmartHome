import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:Home/screens/notifications.dart'; // Import the NotificationService

class ApiService {
  static String baseUrl = "http://192.168.178.210:5000"; // Default IP for general operations
  static String sensorBaseUrl = "http://192.168.26.248:80"; // Separate IP for sensor data

  // Update base IP for general operations (doors, lights, fans, etc.)
  static void updateBaseUrl(String ipAddress) {
    baseUrl = "http://$ipAddress:5000";
  }

  // Update IP for sensor data specifically
  static void updateSensorBaseUrl(String ipAddress) {
    sensorBaseUrl = "http://$ipAddress:80";
  }

  // Fetch sensor data using ONLY the sensorBaseUrl
  static Future<Map<String, dynamic>?> fetchSensorData() async {
    try {
      final response = await http.get(Uri.parse("$sensorBaseUrl/sensors"));

      if (response.statusCode == 200) {
        Map<String, dynamic> data = jsonDecode(response.body);

        // Ensure all numerical values are double
        data = data.map((key, value) {
          if (value is int) {
            return MapEntry(key, value.toDouble());  // Convert int to double
          }
          return MapEntry(key, value);
        });

        // Check for low sensor values and send notifications
        if (data['Soil Moisture'] != null && data['Soil Moisture'] < 400) {
          NotificationService.showNotification(
            "Warning",
            "Moisture level is low, motor is on.",
          );
        }

        if (data['Light Intensity'] != null && data['Light Intensity'] < 600) {
          NotificationService.showNotification(
            "Warning",
            "Light intensity is low.",
          );
        }

        if (data['Motion Detected'] != null && data['Motion Detected'] == true) {
          NotificationService.showNotification(
            "Alert",
            "Motion detected in the field.",
          );
        }

        if (data['Temperature'] != null && data['Fan Status'] != null &&
            data['Temperature'] > 35 && data['Fan Status'] == 'on') {
          NotificationService.showNotification(
            "Alert",
            "Temperature is high, fan is on.",
          );
        }

        if (data['Gas Leak'] != null && data['Windows'] != null &&
            data['Gas Leak'] == true && data['Windows'] == 'opened') {
          NotificationService.showNotification(
            "Warning",
            "Gas leak detected, windows are opened.",
          );
        }

        return data;
      } else {
        print("Failed to load sensor data. Status code: ${response.statusCode}");
        return null;
      }
    } catch (e) {
      print("Error fetching sensor data: $e");
      return null;
    }
  }


  // Unlock door
  static Future<bool> unlockDoor() async {
    return await _sendGeneralRequest("/unlock");
  }

  // Lock door
  static Future<bool> lockDoor() async {
    return await _sendGeneralRequest("/lock");
  }

  // Unlock gate
  static Future<bool> unlockGate() async {
    return await _sendGeneralRequest("/unlock_gate");
  }

  // Lock gate
  static Future<bool> lockGate() async {
    return await _sendGeneralRequest("/lock_gate");
  }

  // Toggle lights and fans (generic)
  static Future<bool> toggleDevice(String device) async {
    return await _sendGeneralRequest("/toggle?device=$device");
  }

  // Enable Night Mode
  static Future<bool> nightModeOn() async {
    return await _sendGeneralRequest("/night_mode_on");
  }

  // Disable Night Mode
  static Future<bool> nightModeOff() async {
    return await _sendGeneralRequest("/night_mode_off");
  }

  // Generic request sender for general API actions (excluding sensor data)
  static Future<bool> _sendGeneralRequest(String endpoint) async {
    try {
      final response = await http.get(Uri.parse("$baseUrl$endpoint"));
      return response.statusCode == 200;
    } catch (e) {
      print("Error in request to $endpoint: $e");
      return false;
    }
  }
}
